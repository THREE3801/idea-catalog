# Handoff: 意图行 · 点子索引卡(Idea Catalog)

## Overview
一个**单用户**的个人点子记录器。核心信条:**记录要快到没有摩擦,整理是可选的,不整理也完全可用。**

本方向("意图行")把捕获压到极致:界面只有**一行输入**。用户用自然语言写一句话,系统**实时解析**出标题、截止日期、标签、链接、状态,回车即归档。用户只负责"想",结构由解析器抽取——无需点日期选择器、无需选状态、无需切字段。

## About the Design Files
本包内的文件是**用 HTML 制作的设计参考稿**——展示预期外观与行为的原型,不是可直接复制上线的生产代码。任务是:在目标代码库的既有技术环境(React / Vue / SwiftUI / 原生等)里,用其既定模式与组件库,**重建这份 HTML 设计**;若尚无既有环境,则为项目选择最合适的框架实现之。

原型文件:`Idea Catalog.dc.html`(这是一个自定义 "Design Component" 格式,`<x-dc>` 内是模板、`<script>` 内是逻辑类;仅作视觉与交互参考,不要照搬这套运行时)。

## Fidelity
**高保真(hifi)。** 颜色、字体、间距、交互均为最终值,请像素级还原。下方 Design Tokens 给出全部精确数值。

## Screens / Views

### 单屏:意图捕获(Intent Capture)
- **Name**: 意图行主界面
- **Purpose**: 用户在唯一的输入行里用自然语言记点子;下方是按状态筛选的点子流。全部操作(记录、切状态、补充、删除、筛选、导出)都在这一屏完成。
- **Layout**(自上而下,单列,居中):
  1. **卡片容器**:最大宽度约 660px,背景 `#EFEDE4`,`1px solid #CFCDC2` 边框,`border-radius: 8px`,`padding: 32px 34px 30px`,阴影 `0 10px 30px rgba(60,55,40,0.10)`。整页背景为暖灰纸感 `radial-gradient(120% 90% at 50% 0%, #DAD8CE, #CFCDC2)`。
  2. **容器头**:`display:flex; justify-content:space-between`。左:`IDEA CATALOG · 意图捕获`(mono 11px,字距 0.16em,`#A09E93`)。右:总条数 `N 条`(mono 12px,`#AEACA1`)。
  3. **意图输入行**(核心):见下方 Components。
  4. **实时解析预览**:仅当输入非空时出现,见 Components。
  5. **状态筛选 tab 行**:文字型 tab,`margin: 26px 0 20px`,`gap: 16px`。
  6. **点子流**:每条一行,顶部 `1px solid #E4E2D8` 分隔线。

- **Components**:

  **1. 意图输入行**
  - 容器:`display:flex; gap:12px; align-items:flex-start; padding:16px 18px; background:#FCFBF6; border:1px solid #D6D5CA; border-radius:8px`。
  - 左前缀图标:`✳`,mono 15px,`#C9B27A`(金褐,象征"待归档")。
  - `<input>`:占满剩余宽度,无边框透明背景,`font: 17px 'Source Serif 4', serif`,`color:#26261F`,`line-height:1.5`。placeholder:`写点什么都行:读完《思维的乐趣》写笔记 下周五前 #写作 …`,placeholder 色 `#B0AEA3`。
  - 右后缀:回车符 `↵`,mono 13px,`#BDBBB0`。
  - 提交:按 **Enter** 归档,输入行清空。

  **2. 实时解析预览**(输入非空时显示,`popIn` 动画 0.16s)
  - 容器:`margin-top:12px; padding:12px 14px; background:#FCFBF6; border:1px solid #E7E5DB; border-radius:6px`。
  - 标签行:`识别到`(mono 11px,`#B0AEA3`),下方 `display:flex; flex-wrap:wrap; gap:8px`。
  - **标题 chip**:抽取出的标题文本,`font:600 14px 'Source Serif 4', serif`,`#26261F`,单行省略,`max-width:340px`。
  - **facet chips**(每个识别到的结构化字段一枚),圆角胶囊 `padding:3px 10px; border-radius:999px; font:11.5px mono`;chip 内前缀是字段名(`截止`/`状态`/`标签`/`链接`,`opacity:0.6; margin-right:5px`),后跟值:
    - 截止:值为 `YYYY/M/D(剩N天)` 或 `(超期)`/`(今天)`。临近(≤3天)用红:`color:#B3423A; background:#FBEAE8`;否则中性 `color:#4B4A44; background:#EDEBE2`。
    - 状态:仅当非默认("待验证")时出现,`color`/`background` 取对应状态色(见 tokens)。
    - 标签:`#写作` 等,中性色。
    - 链接:值为 `已识别`,中性色。
  - 输入为空时,此区替换为一行灰色提示:`试试:明天 · 下周五 · 3天后 · #标签 · 粘贴链接 · "做完了"/"在做" —— 都会被自动读出来`(mono 12.5px,`#B8B6AB`,关键词 `#8A8981`)。

  **3. 状态筛选 tab**(文字型下划线 tab)
  - 每个 tab:`display:inline-flex; align-items:baseline; gap:5px; font:13px mono; padding-bottom:3px; border:none; background:none; cursor:pointer`。
  - 选项:`全部` + 四状态(待验证/进行中/已完成/已放弃)。
  - 激活态:文字 `#26261F`,底部 `border-bottom:2px solid #26261F`;未激活:`#A6A498`,透明下划线。
  - 每个 tab 末尾附计数(mono 11px);激活 `#87867E`,未激活 `#BDBBB0`。

  **4. 点子行**(`cardIn` 动画 0.3s)
  - 容器:`display:flex; gap:14px; padding:16px 0; border-top:1px solid #E4E2D8`。
  - **状态球**(左,可点):`20px × 20px` 圆,`margin-top:3px`,背景取状态浅底 `bg`,`2px solid` 取状态点色 `dot`。**点击循环切换状态**(待验证→进行中→已完成→已放弃→待验证)。`title="点击切换状态"`。
  - **右侧主体**(flex:1):
    - 标题行:`display:flex; align-items:baseline; gap:10px`。标题 `<h3>`:`font:600 18px 'Source Serif 4', serif`,`#26261F`,`line-height:1.4`,`text-wrap:pretty`,占满。右侧操作组:`补充`按钮(mono 11.5px,`#9A998F`,hover `#26261F`);`删`按钮(mono 11.5px,`#C6C4B9`,hover `#B3423A`)。
    - 备注(有则显示):`<p>`,`font:15px 'Source Serif 4', serif`,`#5C5B54`,`line-height:1.6`,`margin-top:6px`。
    - meta 行(`margin-top:9px; gap:9px; flex-wrap:wrap`):状态文字(mono 11.5px,取状态前景色 `fg`);截止 facet(见下);标签 chips(`#写作` 等,mono 11px,`#87867E`,`background:#EDEBE2`,`padding:1px 8px; border-radius:999px`);链接(`↗ 链接`,mono 11.5px,`#2D5A6B`)。
    - 截止 facet:已完成/已放弃时显示 `截止 YYYY/M/D`(灰 `#9A998F`);进行中/待验证时显示 `剩N天`/`今天截止`/`超期N天`,临近(≤3天)红胶囊 `#B3423A` on `#FBEAE8`,否则 `#87867E` 无底。

  **5. 删除确认**(内联,非弹窗)
  - 点`删`→ 该行操作组替换为:`确认删`(红 `#B3423A`)+ `取消`(灰 `#8A8981`)。

  **6. 补充编辑区**(点`补充`展开,内联在该行下方)
  - `margin-top:12px; display:flex; flex-direction:column; gap:9px`。
  - `<textarea>` 备注(2 行,`font:14px serif`);一行内 `<input>` 链接(flex:1,mono 13px)+ `<input type="date">` 截止。
  - 底部右对齐:`取消`(文本按钮)+ `保存`(深色实心 `#2A2A28`,白字,`border-radius:4px`,`padding:6px 16px`)。
  - 输入框统一:`border:1px solid #DEDDD3; border-radius:4px; background:#FFFEFA`。

  **7. 导出**(可选,放容器头)
  - 按钮 `↓ 导出`,导出全部点子为 `ideas.json`(下载)。mono 12px,`#4B4A44`,`background:#FCFBF6`,`border:1px solid #D8D7CD`,hover 边框 `#2A2A28`。

## Interactions & Behavior

### 自然语言解析(核心逻辑)
输入文本按以下顺序抽取,抽出的片段从标题里移除,剩余即标题:
1. **链接**:匹配 `https?://…` 或 `www.xxx.yyy/…` 或裸域名;无协议则补 `https://`。
2. **标签**:`#词`(空格/井号分隔),可多个。
3. **截止日期**(相对"今天"计算,输出 ISO `YYYY-MM-DD`):
   - `今天`=0、`明天`=+1、`后天`=+2、`大后天`=+3
   - `N天后` / `N天内`=+N
   - `[下[下]]周/星期/礼拜 + 一二三四五六日/天`:取该星期几的下一个出现日(当天则跳到下周);每个"下"再 +7 天
   - `M月D日/号`:当年该日期,若已过则算下一年
   - `M/D`:同上
4. **状态**关键词:`做完了/完成/搞定/done/发布了`→已完成;`在做/进行中/正在/开工`→进行中;`放弃/不做了/算了/废弃`→已放弃;都没有→待验证(默认)。同时从标题移除这些词及"前/之前/截止/deadline"。
5. **标题**:剩余文本,压缩连续空白并 trim;若为空则回退为原始输入。

解析在**每次输入变化时实时运行**并更新预览;**Enter** 用最终解析结果创建点子并置顶。

### 其它行为
- **状态球点击**:循环切换四状态(按 待验证→进行中→已完成→已放弃 顺序)。
- **筛选 tab**:切换只影响列表过滤,`全部`显示所有。
- **补充**:展开内联编辑(备注/链接/截止),保存后合并回该点子。
- **删除**:两步——点`删`出现`确认删`/`取消`,确认后移除。
- **新点子**始终插入列表顶部(倒序,最新在上)。
- **动画**:`cardIn`(opacity+translateY(5px)→0,0.3s ease)用于新行;`popIn`(opacity+translateY(-4px)→0,0.16s)用于解析预览。缓动统一 `ease`。

## State Management
- `ideas: Idea[]` —— 全部点子。`Idea = { id, num, title, note, link, deadline(ISO或''), status, tags:string[], createdAt(ISO) }`。`num` 为自增编号(当前最大 +1)。
- `draft: string` —— 输入行当前文本。
- `filter: 'all' | status` —— 当前筛选。
- `editing: id | null` —— 正在补充编辑的点子。
- `confirming: id | null` —— 正在确认删除的点子。
- `editDraft: { note, link, deadline }` —— 补充编辑暂存。
- 解析预览为输入文本的**纯函数派生**,不需独立 state。
- **持久化**:单用户、无账号;建议把 `ideas` 存本地(localStorage / 文件 / 轻量后端均可),读取时恢复。导出为 JSON 即数据出口。
- 无需登录/多用户,但数据结构应为未来多用户预留(每条已有独立 id)。

## Design Tokens

### Colors
- 页面背景渐变:`#DAD8CE` → `#CFCDC2`
- 卡片容器背景:`#EFEDE4`;边框 `#CFCDC2`
- 输入/点子表面:`#FCFBF6`;编辑输入框 `#FFFEFA`
- 分隔线:`#E4E2D8`;通用浅边框 `#DEDDD3` / `#E7E5DB`
- 主文字:`#26261F`;正文/备注 `#5C5B54`;次要 `#8A8981` / `#9A998F`;更淡 `#AEACA1` / `#B0AEA3` / `#BDBBB0` / `#C6C4B9`
- 深色实心(保存按钮/强调):`#2A2A28`,其上文字 `#F4F3EE`
- 链接:`#2D5A6B`;hover `#B3423A`
- 金褐前缀图标:`#C9B27A`
- 标签 chip 底:`#EDEBE2`
- **状态色**(前景 fg / 浅底 bg / 圆点 dot):
  - 待验证 pending:`fg #A9761D` · `bg #F6EDD6` · `dot #C08A2E`
  - 进行中 doing:`fg #2D5A6B` · `bg #E3EDF0` · `dot #2D5A6B`
  - 已完成 done:`fg #3F7A57` · `bg #E6F0E9` · `dot #3F7A57`
  - 已放弃 dropped:`fg #87867E` · `bg #EDEDE8` · `dot #ABAAA1`
- 紧急/超期红:`#B3423A`,红底 `#FBEAE8`

### Typography
- 衬线(标题/正文/输入):**Source Serif 4**(400/500/600/700,含 italic 400)
- 等宽(元信息/标签/按钮/数字):**IBM Plex Mono**(400/500/600)
- 尺寸:标题 18px/600、输入 17px、正文 15px、meta/mono 11–13px。行高:标题 1.4、正文 1.6。

### Spacing / Radius / Shadow
- 容器 padding `32px 34px 30px`;输入行 padding `16px 18px`;点子行 padding `16px 0`。
- 圆角:容器 8px、输入/预览 6–8px、chip/标签 999px(胶囊)、按钮 4px、状态球 50%。
- 阴影:容器 `0 10px 30px rgba(60,55,40,0.10)`。
- gap:解析 chips 8px、meta 9px、tab 16px、行内主体 14px。

## Assets
无位图/图标资源。所有图形符号为文本字符:`✳`(前缀)、`↵`(回车)、`↗`(链接)、`↓`(导出)。字体经 Google Fonts 引入(Source Serif 4 + IBM Plex Mono),目标代码库可用其既有等价字体或同名字体。

## Files
- `Idea Catalog.dc.html` —— 完整原型。**2a 意图行**是采纳方向,位于 `id="turn2"` 内 `id="2a"` 的区块。文件中另含未采纳的探索(turn1 三张卡、2b 语义画布、turn3 合并方向),实现时可忽略,仅参考 2a。
- 逻辑参考:文件内 `<script>` 的 `Component` 类中 `parseInput` / `parseDate` / `keyAddP` / `rowOf` / `buildIntent` 等方法即为解析与列表逻辑的完整实现,可直接翻译到目标语言。
